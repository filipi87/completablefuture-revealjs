package br.com.apresentacao;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import br.com.apresentacao.step.CombineListFunction;
import br.com.apresentacao.step.CountWordsFunction;
import br.com.apresentacao.step.HTMLParserFunction;
import br.com.apresentacao.step.HTTPGetFunction;
import br.com.apresentacao.step.PrintFunction;
import br.com.apresentacao.step.SortFunction;
import br.com.apresentacao.step.TokenizerFunction;

public class MainAsync {
	// static ExecutorService executor = Executors.newFixedThreadPool(2);
	static String n1 = "http://www1.folha.uol.com.br/mercado/2017/10/1928970-estados-desistem-do-programa-de-privatizacao-do-saneamento.shtml";
	static String n2 = "http://www1.folha.uol.com.br/poder/2017/10/1928946-socio-de-filho-de-lula-era-fachada-para-repasses-da-oi.shtml";
	static String n3 = "http://g1.globo.com/politica/blog/valdo-cruz/post/economia-em-recuperacao-vai-influenciar-eleicao-diz-meirelles.html";
	static String n4 = "https://br.motorsport.com/f1/news/imbativel-hamilton-repete-dominio-no-tl2-massa-e-8-968063/?s=1&r=166223&em=1";
	
	public static void main(String[] args) throws Exception {
		final long init = System.currentTimeMillis();
		List<String> news = Arrays.asList(n1, n2, n3, n4);
		
		CompletableFuture<List<String>> combined = CompletableFuture.completedFuture(new ArrayList<String>());
		for (String n : news) {
			CompletableFuture<List<String>> newsWords = new HTTPGetFunction(n).get()//
					.thenApply(new HTMLParserFunction())//
					// .thenApplyAsync(new HTMLParserFunction(), executor)//
					.thenApply(new TokenizerFunction());

			combined = combined.thenCombine(newsWords, new CombineListFunction<>());
		}
		
		combined.thenApply(new CountWordsFunction())//
				.thenApply(new SortFunction())//
				.whenComplete(new PrintFunction())//
				.thenRun(() -> {
					System.out.println("Tempo total: " + (System.currentTimeMillis() - init));
				})//
				.get();//
	//	TimeUnit.SECONDS.sleep(3);

	}

}
