package br.com.apresentacao.step;

import java.util.List;
import java.util.function.BiFunction;

public class CombineListFunction<T> implements BiFunction<List<T>, List<T>, List<T>> {

	@Override
	public List<T> apply(List<T> l1, List<T> l2) {
		l1.addAll(l2);
		return l1;
	}

}
