package br.com.apresentacao.step;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CountWordsFunction implements Function<List<String>, Map<String, Long>> {

	@Override
	public Map<String, Long> apply(List<String> words) {
		Map<String, Long> map = words.parallelStream()
				.collect(Collectors.groupingBy((s)->s, Collectors.counting()));
		return map;
	}

}
