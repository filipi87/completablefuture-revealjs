package br.com.apresentacao.step;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeSet;
import java.util.function.Function;
import java.util.stream.Collectors;

public class SortFunction implements Function<Map<String, Long>, Map<String, Long>>{

	@Override
	public Map<String, Long> apply(Map<String, Long> map) {
		TreeSet<Long> treeSet = new TreeSet<>(map.values());
		Iterator<Long> iterator = treeSet.descendingIterator();
		
		 Map<Long, List<String>> groups = map.entrySet().stream()//
				.collect(Collectors.groupingBy(Map.Entry::getValue, //
							Collectors.mapping(Map.Entry::getKey,Collectors.toList())));
		
		LinkedHashMap<String, Long> result = new LinkedHashMap<>();
		while(iterator.hasNext()) {
			Long count = iterator.next();
			List<String> list = groups.get(count);
			for (String entry : list) {
				result.put(entry, count);
			}
		}
		return result;
	}

}
