package br.com.apresentacao.step;

import java.util.function.Function;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class HTMLParserFunction implements Function<String, String> {

	@Override
	public String apply(String text) {
		StringBuilder sb = new StringBuilder();
		try {
			Document doc = Jsoup.parse(text);
			Elements newsHeadlines = doc.select("p");
			for (Element element : newsHeadlines) {
				sb.append(element.text());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sb.toString();
	}

}
