package br.com.apresentacao.step;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.function.Supplier;

import jdk.incubator.http.HttpClient;
import jdk.incubator.http.HttpRequest;
import jdk.incubator.http.HttpResponse;
import jdk.incubator.http.HttpResponse.BodyHandler;

public class HTTPGetFunction implements Supplier<CompletableFuture<String>> {
	String uriStr;
	
	public HTTPGetFunction(String uriStr) {
		super();
		this.uriStr = uriStr;
	}

	@Override
	public CompletableFuture<String> get() {
		HttpClient client = HttpClient.newHttpClient();
		try {
			URI uri = new URI(uriStr);
			HttpRequest.Builder builder = HttpRequest.newBuilder().version(client.version()).uri(uri).GET();
			CompletableFuture<HttpResponse<String>> future = client.sendAsync(builder.build(), BodyHandler.asString());
			return future.handle((response, erro) -> {
				if (erro != null) {
					erro.printStackTrace();
				}
				return response == null ? "" : response.body();
			});
		} catch (URISyntaxException e) {
			return CompletableFuture.failedFuture(e);
		}
	}

}
