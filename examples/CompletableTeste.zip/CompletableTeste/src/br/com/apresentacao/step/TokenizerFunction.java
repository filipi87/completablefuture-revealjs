package br.com.apresentacao.step;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.function.Function;

public class TokenizerFunction implements Function<String, List<String>> {

	@Override
	public List<String> apply(String texto) {
		StringTokenizer t = new StringTokenizer(texto, " \t\n\r\f,;.");
        List<String> result = new ArrayList<>();
	    while (t.hasMoreTokens()){
	    	result.add(t.nextToken());
	    }
		return result	;
	}

}
