package br.com.apresentacao.step;

import java.util.Map;
import java.util.function.BiConsumer;

public class PrintFunction implements BiConsumer<Map<String, Long>, Throwable> {

	@Override
	public void accept(Map<String, Long> map, Throwable erro) {
		map.forEach((word, count) -> {
			System.out.println(word + " - " + count);
		});

	}

}
