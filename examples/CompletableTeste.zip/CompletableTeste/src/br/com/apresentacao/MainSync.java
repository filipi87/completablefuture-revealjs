package br.com.apresentacao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import br.com.apresentacao.step.CombineListFunction;
import br.com.apresentacao.step.CountWordsFunction;
import br.com.apresentacao.step.HTMLParserFunction;
import br.com.apresentacao.step.HTTPGetFunction;
import br.com.apresentacao.step.PrintFunction;
import br.com.apresentacao.step.SortFunction;
import br.com.apresentacao.step.TokenizerFunction;

public class MainSync {
	static String n1 = "http://www1.folha.uol.com.br/mercado/2017/10/1928970-estados-desistem-do-programa-de-privatizacao-do-saneamento.shtml";
	static String n2 = "http://www1.folha.uol.com.br/poder/2017/10/1928946-socio-de-filho-de-lula-era-fachada-para-repasses-da-oi.shtml";
	static String n3 = "http://g1.globo.com/politica/blog/valdo-cruz/post/economia-em-recuperacao-vai-influenciar-eleicao-diz-meirelles.html";
	static String n4 = "https://br.motorsport.com/f1/news/imbativel-hamilton-repete-dominio-no-tl2-massa-e-8-968063/?s=1&r=166223&em=1";

	public static void main(String[] args) throws Exception {
		final long init = System.currentTimeMillis();
		List<String> news = Arrays.asList(n1, n2, n3, n4);
		List<String> combined = new ArrayList<>();
		for (String n : news) {
			List<String> words = new HTTPGetFunction(n).get()//
					.thenApply(new HTMLParserFunction())//
					.thenApply(new TokenizerFunction()).get();

			combined.addAll(words);
		}
		CompletableFuture<List<String>> future = CompletableFuture.completedFuture(combined);
		future.thenApply(new CountWordsFunction())//
				.thenApply(new SortFunction())//
				.whenComplete(new PrintFunction())//
				.thenRun(() -> {
					System.out.println("Tempo total: " + (System.currentTimeMillis() - init));
				}).get();//

	}
}
