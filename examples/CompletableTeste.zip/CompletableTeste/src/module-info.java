/**
 * @author emerson
 *
 */
module fteste {
	exports br.com.apresentacao;
	requires jdk.incubator.httpclient;
	requires java.xml;
	requires jsoup;
}